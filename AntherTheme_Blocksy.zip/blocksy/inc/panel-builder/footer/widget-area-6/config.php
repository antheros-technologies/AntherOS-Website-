<?php

$config = [
	'name' => __('Widget Area 6', 'blocksy')
];

